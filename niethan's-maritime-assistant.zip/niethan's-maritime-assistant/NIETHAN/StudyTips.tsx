
import React from 'react';
import { Lightbulb, Clock, CheckCircle, Target, BookOpen, UserCheck } from 'lucide-react';

const StudyTips: React.FC = () => {
  const tips = [
    {
      title: "The Chart visualization technique",
      description: "When studying navigation, don't just read the coordinates. Visualize them on a mental chart. Use physical maps when possible to build spatial reasoning.",
      icon: <Target className="text-red-500" />,
      color: "bg-red-50 border-red-100"
    },
    {
      title: "Pomodoro for Dense Regulations",
      description: "MARPOL and COLREGs are dense. Use 25-minute focus sessions followed by 5-minute breaks to keep your brain fresh.",
      icon: <Clock className="text-emerald-500" />,
      color: "bg-emerald-50 border-emerald-100"
    },
    {
      title: "Mnemonic Devices",
      description: "Create rhymes or acronyms for ship lights and signals. Example: 'Red over Red, the Captain is dead (Not Under Command).'",
      icon: <Lightbulb className="text-amber-500" />,
      color: "bg-amber-50 border-amber-100"
    },
    {
      title: "Peer Teaching",
      description: "Explain a concept like 'Metacentric Height' to a classmate. If you can explain it simply, you understand it deeply.",
      icon: <UserCheck className="text-blue-500" />,
      color: "bg-blue-50 border-blue-100"
    }
  ];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="text-center max-w-2xl mx-auto space-y-4">
        <h2 className="text-3xl font-heading font-bold text-slate-800">Study Like a Captain</h2>
        <p className="text-slate-600">Master your Bachelor of Science in Marine Transportation with these proven academic strategies tailored for maritime students.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {tips.map((tip, idx) => (
          <div key={idx} className={`p-6 rounded-3xl border ${tip.color} shadow-sm transition-transform hover:scale-[1.02]`}>
            <div className="flex items-center gap-4 mb-4">
              <div className="p-3 bg-white rounded-2xl shadow-sm">
                {tip.icon}
              </div>
              <h3 className="font-bold text-slate-800">{tip.title}</h3>
            </div>
            <p className="text-slate-700 text-sm leading-relaxed">{tip.description}</p>
          </div>
        ))}
      </div>

      <div className="bg-slate-900 rounded-3xl p-8 text-white">
        <h3 className="text-xl font-heading font-bold mb-6 flex items-center gap-2">
          <CheckCircle className="text-blue-400" />
          Pre-Exam Checklist
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {[
            "Review SOLAS updates",
            "Practice Chart Work (Rule of 12ths)",
            "Identify all Buoyage System A & B",
            "Memorize Fog Signals",
            "Review Cargo Stowage Calculations",
            "Double-check Tides and Current problems"
          ].map((item, idx) => (
            <div key={idx} className="flex items-center gap-3 p-3 bg-slate-800/50 rounded-xl border border-slate-700">
              <div className="w-5 h-5 rounded-full border-2 border-blue-500 flex-shrink-0" />
              <span className="text-sm text-slate-300">{item}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default StudyTips;
