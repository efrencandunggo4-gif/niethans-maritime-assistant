
import React from 'react';
import { 
  LayoutDashboard, 
  MessageSquare, 
  BookMarked, 
  Lightbulb, 
  User, 
  Menu, 
  X, 
  Anchor 
} from 'lucide-react';
import { AppSection } from '../types';
import { STUDENT_PROFILE } from '../constants';

interface LayoutProps {
  activeSection: AppSection;
  setActiveSection: (section: AppSection) => void;
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ activeSection, setActiveSection, children }) => {
  const [isSidebarOpen, setIsSidebarOpen] = React.useState(false);

  const navItems = [
    { id: AppSection.DASHBOARD, label: 'Dashboard', icon: LayoutDashboard },
    { id: AppSection.CHAT, label: 'Academic Assistant', icon: MessageSquare },
    { id: AppSection.RESOURCES, label: 'Maritime Resources', icon: BookMarked },
    { id: AppSection.STUDY_TIPS, label: 'Study Strategies', icon: Lightbulb },
  ];

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      {/* Mobile Sidebar Toggle */}
      <button 
        onClick={() => setIsSidebarOpen(!isSidebarOpen)}
        className="lg:hidden fixed top-4 left-4 z-50 p-2 bg-blue-600 text-white rounded-lg shadow-lg"
      >
        {isSidebarOpen ? <X size={20} /> : <Menu size={20} />}
      </button>

      {/* Sidebar */}
      <aside className={`
        fixed inset-y-0 left-0 z-40 w-64 bg-slate-900 text-white transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:inset-0
        ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <div className="flex flex-col h-full">
          {/* Logo/Brand */}
          <div className="p-6 flex items-center gap-3 border-b border-slate-800">
            <div className="p-2 bg-blue-600 rounded-lg">
              <Anchor className="w-6 h-6 text-white" />
            </div>
            <span className="font-heading font-bold text-lg tracking-tight">Niethan's Hub</span>
          </div>

          {/* Navigation */}
          <nav className="flex-1 px-4 py-6 space-y-2 overflow-y-auto">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  setActiveSection(item.id);
                  setIsSidebarOpen(false);
                }}
                className={`
                  w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200
                  ${activeSection === item.id 
                    ? 'bg-blue-600 text-white shadow-md' 
                    : 'text-slate-400 hover:bg-slate-800 hover:text-white'}
                `}
              >
                <item.icon size={20} />
                <span className="font-medium">{item.label}</span>
              </button>
            ))}
          </nav>

          {/* User Profile */}
          <div className="p-4 border-t border-slate-800">
            <div className="flex items-center gap-3 p-3 bg-slate-800/50 rounded-2xl">
              <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold">
                {STUDENT_PROFILE.name.charAt(0)}
              </div>
              <div className="overflow-hidden">
                <p className="text-sm font-semibold truncate">{STUDENT_PROFILE.name}</p>
                <p className="text-xs text-slate-400 truncate">{STUDENT_PROFILE.course}</p>
              </div>
            </div>
          </div>
        </div>
      </aside>

      {/* Backdrop for mobile */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-30 lg:hidden" 
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 bg-slate-50 relative">
        <header className="h-16 bg-white border-b border-slate-200 px-8 flex items-center justify-between sticky top-0 z-10">
          <h1 className="font-heading text-xl font-bold text-slate-800 lg:ml-0 ml-12">
            {navItems.find(n => n.id === activeSection)?.label}
          </h1>
          <div className="flex items-center gap-4 text-slate-500 text-sm font-medium">
             <span className="hidden sm:inline">AMA Kidapawan City</span>
             <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-4 sm:p-8">
          <div className="max-w-5xl mx-auto h-full">
            {children}
          </div>
        </div>
      </main>
    </div>
  );
};

export default Layout;
