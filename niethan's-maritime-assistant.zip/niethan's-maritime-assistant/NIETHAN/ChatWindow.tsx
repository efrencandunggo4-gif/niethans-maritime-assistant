
import React, { useState, useRef, useEffect } from 'react';
import { Send, User, Bot, Loader2, Link as LinkIcon, Info } from 'lucide-react';
import { Message } from '../types';
import { sendMessageToGemini } from '../geminiService';
import ReactMarkdown from 'https://esm.sh/react-markdown@9';

interface ChatWindowProps {
  initialPrompt?: string;
}

const ChatWindow: React.FC<ChatWindowProps> = ({ initialPrompt }) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      role: 'assistant',
      content: "Hello Niethan! I'm your maritime academic assistant. Whether you need help with navigation problems, seamanship reports, or just some study tips for your exams at AMA Kidapawan, I'm ready to help. What's on your mind today?",
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  useEffect(() => {
    if (initialPrompt) {
      handleSend(initialPrompt);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialPrompt]);

  const handleSend = async (content: string) => {
    if (!content.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const history = messages.map(msg => ({
        role: msg.role === 'user' ? 'user' : 'model' as const,
        parts: [{ text: msg.content }]
      }));

      const response = await sendMessageToGemini(content, history);

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response.text || "I'm sorry, I couldn't process that. Let's try again!",
        groundingUrls: response.groundingUrls,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error(error);
      const errorMessage: Message = {
        id: 'error',
        role: 'assistant',
        content: "Sorry, I encountered an error. Please check your connection or try again later.",
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-10rem)] bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden">
      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex items-start gap-4 ${message.role === 'user' ? 'flex-row-reverse' : ''}`}
          >
            <div className={`
              w-10 h-10 rounded-2xl flex items-center justify-center flex-shrink-0 shadow-sm
              ${message.role === 'user' ? 'bg-blue-600 text-white' : 'bg-slate-100 text-blue-600'}
            `}>
              {message.role === 'user' ? <User size={20} /> : <Bot size={20} />}
            </div>
            <div className={`
              max-w-[85%] sm:max-w-[70%] space-y-3
              ${message.role === 'user' ? 'items-end' : 'items-start'}
            `}>
              <div className={`
                p-4 rounded-3xl text-sm sm:text-base leading-relaxed
                ${message.role === 'user' 
                  ? 'bg-blue-600 text-white rounded-tr-none shadow-blue-200 shadow-md' 
                  : 'bg-slate-50 text-slate-800 border border-slate-100 rounded-tl-none'}
              `}>
                <div className="prose prose-sm sm:prose-base max-w-none prose-slate">
                   <ReactMarkdown>{message.content}</ReactMarkdown>
                </div>
              </div>

              {/* Grounding URLs */}
              {message.groundingUrls && message.groundingUrls.length > 0 && (
                <div className="mt-4 p-3 bg-blue-50/50 rounded-2xl border border-blue-100">
                  <p className="text-xs font-bold text-blue-700 mb-2 flex items-center gap-1">
                    <LinkIcon size={12} />
                    Maritime Resources & Citations:
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {message.groundingUrls.map((url, idx) => (
                      <a
                        key={idx}
                        href={url.uri}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-xs bg-white text-blue-600 px-3 py-1 rounded-full border border-blue-200 hover:bg-blue-600 hover:text-white transition-colors"
                      >
                        {url.title}
                      </a>
                    ))}
                  </div>
                </div>
              )}
              
              <p className="text-[10px] text-slate-400 font-medium px-2">
                {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex items-start gap-4 animate-pulse">
            <div className="w-10 h-10 bg-slate-100 rounded-2xl flex items-center justify-center">
              <Loader2 className="animate-spin text-blue-400" size={20} />
            </div>
            <div className="bg-slate-100 h-12 w-32 rounded-3xl rounded-tl-none" />
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-4 sm:p-6 bg-slate-50 border-t border-slate-100">
        <form 
          onSubmit={(e) => { e.preventDefault(); handleSend(input); }}
          className="relative flex items-center gap-3"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask anything about BSMT lessons..."
            className="w-full pl-6 pr-14 py-4 bg-white border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all shadow-sm text-slate-700"
          />
          <button
            type="submit"
            disabled={!input.trim() || isLoading}
            className={`
              absolute right-2 p-2.5 rounded-xl transition-all
              ${!input.trim() || isLoading 
                ? 'bg-slate-100 text-slate-400 cursor-not-allowed' 
                : 'bg-blue-600 text-white hover:bg-blue-700 shadow-md hover:shadow-blue-200'}
            `}
          >
            <Send size={20} />
          </button>
        </form>
        <div className="mt-4 flex items-center justify-center gap-4">
          <p className="text-[10px] text-slate-400 uppercase tracking-widest font-bold flex items-center gap-1">
            <Info size={10} />
            Academic Use Only • Maritime Assistant v1.0
          </p>
        </div>
      </div>
    </div>
  );
};

export default ChatWindow;
