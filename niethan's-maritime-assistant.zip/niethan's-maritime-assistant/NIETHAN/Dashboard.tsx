
import React from 'react';
import { MARITIME_QUICK_TOPICS, STUDENT_PROFILE } from '../constants';
import { BookOpen, GraduationCap, ChevronRight, Waves, Compass, Wind } from 'lucide-react';
import { AppSection } from '../types';

interface DashboardProps {
  setActiveSection: (section: AppSection) => void;
  onQuickAction: (topic: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ setActiveSection, onQuickAction }) => {
  const currentDate = new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Hero Welcome */}
      <div className="relative overflow-hidden bg-gradient-to-br from-blue-700 to-indigo-900 rounded-3xl p-8 text-white shadow-xl">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <p className="text-blue-100 font-medium">{currentDate}</p>
            <h2 className="text-3xl sm:text-4xl font-heading font-bold">
              Ahoy, Niethan! ⚓
            </h2>
            <p className="text-blue-100 max-w-md">
              Ready to navigate through today's lessons? Your maritime assistant is here to help with your BSMT studies.
            </p>
          </div>
          <div className="hidden lg:block">
            <img 
              src="https://picsum.photos/seed/maritime/300/200" 
              alt="Maritime" 
              className="rounded-2xl border-4 border-white/20 shadow-2xl"
            />
          </div>
        </div>
        {/* Background Decorative Elements */}
        <div className="absolute top-0 right-0 -mr-20 -mt-20 opacity-10">
          <Compass className="w-64 h-64 text-white" />
        </div>
      </div>

      {/* Quick Action Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {MARITIME_QUICK_TOPICS.map((topic) => (
          <button
            key={topic.id}
            onClick={() => onQuickAction(topic.label)}
            className="p-6 bg-white rounded-2xl border border-slate-200 hover:border-blue-500 hover:shadow-lg transition-all group text-left"
          >
            <div className="p-3 bg-blue-50 rounded-xl w-fit mb-4 group-hover:bg-blue-600 transition-colors">
              <div className="group-hover:text-white">
                {topic.icon}
              </div>
            </div>
            <h3 className="font-bold text-slate-800 mb-1">{topic.label}</h3>
            <p className="text-xs text-slate-500 flex items-center">
              Get help now <ChevronRight size={14} className="ml-1" />
            </p>
          </button>
        ))}
      </div>

      {/* Main Section Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Study Planner / Focus */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-heading font-bold text-xl text-slate-800 flex items-center gap-2">
                <BookOpen className="text-blue-600" />
                Key BSMT Study Areas
              </h3>
            </div>
            <div className="space-y-4">
              {[
                { title: 'COLREGs Rule of the Road', description: 'Master international regulations for preventing collisions.', icon: <Waves className="text-blue-500" /> },
                { title: 'Ship Stability', description: 'Understanding centers of gravity and buoyancy.', icon: <Wind className="text-cyan-500" /> },
                { title: 'Bridge Equipment', description: 'How to use Radar, ECDIS, and GPS accurately.', icon: <Compass className="text-indigo-500" /> },
              ].map((area, i) => (
                <div key={i} className="flex items-start gap-4 p-4 rounded-2xl hover:bg-slate-50 transition-colors border border-transparent hover:border-slate-100">
                  <div className="p-2 bg-slate-100 rounded-lg">{area.icon}</div>
                  <div>
                    <h4 className="font-bold text-slate-800">{area.title}</h4>
                    <p className="text-sm text-slate-500">{area.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Motivational Sidebar */}
        <div className="space-y-6">
          <div className="bg-amber-50 rounded-3xl p-6 border border-amber-100">
            <h3 className="font-bold text-amber-900 flex items-center gap-2 mb-4">
              <GraduationCap size={20} />
              Daily Study Tip
            </h3>
            <p className="text-sm text-amber-800 leading-relaxed italic">
              "When studying navigation, try to visualize the ship's position on a real chart. Practical application makes memory stick better than rote learning."
            </p>
          </div>

          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm">
            <h3 className="font-bold text-slate-800 mb-4">Student Profile</h3>
            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-slate-500">Name</span>
                <span className="text-slate-800 font-medium">{STUDENT_PROFILE.name}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-slate-500">Age</span>
                <span className="text-slate-800 font-medium">{STUDENT_PROFILE.age}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-slate-500">Course</span>
                <span className="text-slate-800 font-medium">{STUDENT_PROFILE.course}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-slate-500">Campus</span>
                <span className="text-slate-800 font-medium">{STUDENT_PROFILE.campus}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
