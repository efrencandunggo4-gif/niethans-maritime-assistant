
export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  groundingUrls?: Array<{ title: string; uri: string }>;
}

export interface StudentProfile {
  name: string;
  age: number;
  course: string;
  campus: string;
}

export enum AppSection {
  DASHBOARD = 'dashboard',
  CHAT = 'chat',
  RESOURCES = 'resources',
  STUDY_TIPS = 'study_tips'
}

export interface ResourceLink {
  title: string;
  description: string;
  icon: string;
}
