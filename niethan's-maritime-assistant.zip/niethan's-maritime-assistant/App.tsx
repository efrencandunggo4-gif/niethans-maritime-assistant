
import React, { useState } from 'react';
import Layout from './components/Layout';
import Dashboard from './components/Dashboard';
import ChatWindow from './components/ChatWindow';
import StudyTips from './components/StudyTips';
import { AppSection } from './types';
import { BookMarked, ExternalLink } from 'lucide-react';

const App: React.FC = () => {
  const [activeSection, setActiveSection] = useState<AppSection>(AppSection.DASHBOARD);
  const [quickPrompt, setQuickPrompt] = useState<string | undefined>(undefined);

  const handleQuickAction = (topic: string) => {
    setQuickPrompt(`Can you help me with ${topic}? Please provide a summary and key points I should focus on for my exams.`);
    setActiveSection(AppSection.CHAT);
  };

  const renderContent = () => {
    switch (activeSection) {
      case AppSection.DASHBOARD:
        return <Dashboard setActiveSection={setActiveSection} onQuickAction={handleQuickAction} />;
      case AppSection.CHAT:
        return <ChatWindow initialPrompt={quickPrompt} />;
      case AppSection.STUDY_TIPS:
        return <StudyTips />;
      case AppSection.RESOURCES:
        return (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[
                { name: 'IMO Official Website', desc: 'International Maritime Organization regulations and news.', link: 'https://www.imo.org' },
                { name: 'MARPOL Annexes', desc: 'Detailed guide on pollution prevention from ships.', link: 'https://www.imo.org/en/About/Conventions/Pages/International-Convention-for-the-Prevention-of-Pollution-from-Ships-(MARPOL).aspx' },
                { name: 'COLREGs 72', desc: 'International Regulations for Preventing Collisions at Sea.', link: 'https://www.imo.org/en/About/Conventions/Pages/COLREG.aspx' },
                { name: 'SeaTerms Maritime Dictionary', desc: 'Essential terminology for deck officers.', link: 'https://www.nautinst.org/' },
              ].map((res, i) => (
                <a 
                  key={i} 
                  href={res.link} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="p-6 bg-white rounded-3xl border border-slate-200 hover:border-blue-500 hover:shadow-lg transition-all flex items-start justify-between"
                >
                  <div className="space-y-2">
                    <div className="p-2 bg-blue-50 rounded-lg w-fit">
                       <BookMarked size={20} className="text-blue-600" />
                    </div>
                    <h3 className="font-bold text-slate-800">{res.name}</h3>
                    <p className="text-sm text-slate-500">{res.desc}</p>
                  </div>
                  <ExternalLink size={18} className="text-slate-300" />
                </a>
              ))}
            </div>
            <div className="bg-blue-600 rounded-3xl p-8 text-white flex flex-col md:flex-row items-center gap-8 shadow-xl">
              <div className="flex-1 space-y-4">
                <h3 className="text-2xl font-heading font-bold">AMA Kidapawan Student Portal</h3>
                <p className="text-blue-100">Quickly access your grades, schedule, and school announcements through the official AMA student dashboard.</p>
                <button className="px-6 py-3 bg-white text-blue-600 rounded-xl font-bold hover:bg-blue-50 transition-colors shadow-lg">
                  Access Portal
                </button>
              </div>
              <div className="w-full md:w-1/3">
                 <img src="https://picsum.photos/seed/school/400/300" alt="School" className="rounded-2xl border-4 border-white/20" />
              </div>
            </div>
          </div>
        );
      default:
        return <Dashboard setActiveSection={setActiveSection} onQuickAction={handleQuickAction} />;
    }
  };

  return (
    <Layout activeSection={activeSection} setActiveSection={setActiveSection}>
      {renderContent()}
    </Layout>
  );
};

export default App;
